"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const cp = require("child_process");
const fs = require("fs");
const FormData = require("form-data");
const node_fetch_1 = require("node-fetch");
const buffer_1 = require("buffer");
const propertiesReader = require("properties-reader");
const xml2js = require("xml2js");
const uuid = require("uuid");
const settings_1 = require("./settings");
const HttpsProxyAgent = require("https-proxy-agent");
const url = require("url");
const fg = require("fast-glob");
let proxyAgent;
let sscCiToken;
let projectVersionId;
let tokenId;
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let inputErrors = settings_1.settings.validate();
            if (inputErrors.length) {
                inputErrors.forEach(x => tl.error(x));
                tl.setResult(tl.TaskResult.Failed, "Incorrect settings");
            }
            else {
                if (settings_1.settings.licenseFile) {
                    const licenseDest = path.join(path.dirname(path.dirname(settings_1.settings.scaExe)), "fortify.license");
                    console.log(`Copying license ${settings_1.settings.licenseFile} to ${licenseDest}`);
                    fs.copyFileSync(settings_1.settings.licenseFile, licenseDest);
                }
                console.log(`Executing ${path.basename(settings_1.settings.scaExe)} --version to determine if the proper Fortify SCA version is installed`);
                try {
                    const p = cp.execFileSync(path.basename(settings_1.settings.scaExe), ['--version']);
                    let versionMatches = p.toString().match(/([0-9]+)/g);
                    let isVersionOk = false;
                    if (p.length > 1) {
                        let versionUnity = parseInt(versionMatches[0]);
                        let versionDecimals = parseInt(versionMatches[1]);
                        isVersionOk = (versionUnity == 16 && versionDecimals >= 11) ||
                            (versionUnity > 16 && versionDecimals >= 10) ||
                            (versionUnity >= 19 && versionDecimals >= 1);
                    }
                    if (!isVersionOk) {
                        throw new Error(tl.loc('version.failure'));
                    }
                }
                catch (e) {
                    console.log(tl.loc('version.failure'));
                    throw e;
                }
                if (settings_1.settings.runFortifyClean) {
                    let sca = getAnalyzer();
                    sca.arg('-clean');
                    handleErrors(sca.execSync({ "failOnStdErr": true, "cwd": path.dirname(settings_1.settings.scaExe) }));
                }
                if (settings_1.settings.runFortifyRulepackUpdate) {
                    handleErrors(tl.execSync(settings_1.settings.scaUpdateExe, '', { "failOnStdErr": true }));
                }
                if (settings_1.settings.runBuildTranslate) {
                    tl.cd(settings_1.settings.sourceBase);
                    tl.mkdirP(settings_1.settings.scaArtifactsDir);
                    if (settings_1.settings.isDotNet) {
                        let solutionFiles = fg.sync(settings_1.settings.fortifyProjects.replace(/\\/g, '/'));
                        let sca;
                        solutionFiles.forEach(function (solPath) {
                            solPath = solPath.replace(/\//g, '\\');
                            sca = getAnalyzer();
                            let parts = path.parse(solPath);
                            let logfile = path.join(settings_1.settings.scaArtifactsDir, parts.base + "_build.log");
                            sca.arg('-logfile');
                            sca.arg(logfile);
                            if (settings_1.settings.buildAnalyzerParams) {
                                sca.line(settings_1.settings.buildAnalyzerParams);
                            }
                            sca.arg('devenv');
                            sca.arg(solPath);
                            sca.arg('/REBUILD');
                            sca.arg('DEBUG');
                            handleErrors(sca.execSync({ "failOnStdErr": true, "cwd": path.dirname(settings_1.settings.scaExe) }));
                        });
                    }
                    else {
                        let sca = getAnalyzer();
                        sca.arg('-logfile');
                        sca.arg(settings_1.settings.buildLogFile);
                        if (settings_1.settings.isJava) {
                            if (settings_1.settings.buildClasspath) {
                                sca.arg('-cp');
                                sca.arg(settings_1.settings.buildClasspath);
                            }
                            if (settings_1.settings.buildSourcePath) {
                                sca.arg('-sourcepath');
                                sca.arg(path.join(process.cwd(), settings_1.settings.buildSourcePath));
                            }
                            sca.arg('-jdk');
                            sca.arg(settings_1.settings.buildSourceVersion);
                        }
                        if (settings_1.settings.buildAnalyzerParams) {
                            sca.line(settings_1.settings.buildAnalyzerParams);
                        }
                        let baseSrcArg = process.cwd();
                        if (settings_1.settings.buildToolOptions) {
                            sca.line(settings_1.settings.buildToolOptions);
                        }
                        else {
                            if (settings_1.settings.fortifySourceTranslate) {
                                let sourcesTranslate = settings_1.settings.fortifySourceTranslate.split('\n');
                                for (let sourceTranslate of sourcesTranslate) {
                                    if (sourceTranslate) {
                                        let srcArg = path.join(baseSrcArg, sourceTranslate);
                                        sca.arg(srcArg);
                                    }
                                }
                            }
                            else {
                                sca.arg(baseSrcArg);
                            }
                            if (settings_1.settings.fortifyOtherTranslate) {
                                sca.arg(settings_1.settings.fortifyOtherTranslate);
                            }
                        }
                        handleErrors(sca.execSync({ "failOnStdErr": true, "cwd": path.dirname(settings_1.settings.sourceBase + '/s') }));
                    }
                }
                if (settings_1.settings.uploadProxyURL) {
                    let proxyOpts;
                    if (settings_1.settings.uploadProxyURL.startsWith('http://') || settings_1.settings.uploadProxyURL.startsWith('https://')) {
                        proxyOpts = url.parse(settings_1.settings.uploadProxyURL);
                    }
                    else {
                        proxyOpts = url.parse('http://' + settings_1.settings.uploadProxyURL);
                    }
                    if (settings_1.settings.uploadProxyUser && settings_1.settings.uploadProxyPass) {
                        proxyOpts.auth = `${settings_1.settings.uploadProxyUser}:${settings_1.settings.uploadProxyPass}`;
                    }
                    proxyAgent = new HttpsProxyAgent(proxyOpts);
                }
                if (settings_1.settings.runFortifyScan) {
                    if (settings_1.settings.fortifyScanType === 'LocalScan') {
                        yield runFortifyLocalScan();
                    }
                    else if (settings_1.settings.fortifyScanType === 'ScanCentralScan') {
                        yield runFortifyScanCentralScan();
                    }
                }
            }
        }
        catch (err) {
            if (err instanceof TimeoutError) {
                tl.setResult(tl.TaskResult.SucceededWithIssues, err.message);
            }
            else if (err instanceof BuildFailureError) {
                let result = settings_1.settings.taskResultForBuildFailureCriteria;
                if (result === 'WARN') {
                    tl.setResult(tl.TaskResult.SucceededWithIssues, err.message);
                }
                else {
                    tl.setResult(tl.TaskResult.Failed, err.message);
                }
            }
            else if (err instanceof Error) {
                tl.setResult(tl.TaskResult.Failed, err.message);
            }
            else {
                tl.setResult(tl.TaskResult.Failed, err.toString());
            }
        }
        finally {
            yield deleteTempToken();
        }
    });
}
function getAnalyzer() {
    var sca = tl.tool(path.basename(settings_1.settings.scaExe));
    sca.arg('-b');
    sca.arg(settings_1.settings.fortifyBuildId);
    if (settings_1.settings.scaVerbose) {
        sca.arg('-verbose');
    }
    if (settings_1.settings.scaDebug) {
        sca.arg('-debug');
    }
    return sca;
}
function handleErrors(retVal) {
    if (retVal.code) {
        throw new Error(`System call exited with status ${retVal.code}`);
    }
}
function runFortifyScanCentralScan() {
    return __awaiter(this, void 0, void 0, function* () {
        const jobToken = runScanCentralStartCommand();
        if (settings_1.settings.scanCentralRunFortifyUpload && settings_1.settings.fortifyBuildFailureCriteria) {
            yield pollArtifactStateForScanCentral(jobToken);
            projectVersionId = yield getProjectVersionIdForScanCentral();
            yield calcStats(settings_1.settings.fortifyBuildFailureCriteria);
        }
    });
}
function runScanCentralStartCommand() {
    sscCiToken = settings_1.settings.fortifyAuth;
    console.log("INFO: Checking for scancentral executable on PATH.");
    let scancentralPath;
    if (fs.existsSync(settings_1.settings.scanCentralExe)) {
        scancentralPath = settings_1.settings.scanCentralExe;
    }
    else {
        console.log("WARNING: Could not find scancentral executable, trying cloudscan instead.");
        scancentralPath = settings_1.settings.cloudscanExe;
    }
    let scanCentralRunner = tl.tool(path.basename(scancentralPath));
    scanCentralRunner.arg('-sscurl');
    scanCentralRunner.arg(trimUrl(settings_1.settings.sscUrl));
    scanCentralRunner.arg('-ssctoken');
    scanCentralRunner.arg(sscCiToken);
    scanCentralRunner.arg('start');
    scanCentralRunner.arg('-b');
    scanCentralRunner.arg(settings_1.settings.fortifyBuildId);
    if (settings_1.settings.scanCentralHasRulePackPath) {
        scanCentralRunner.arg('-rules');
        scanCentralRunner.arg(settings_1.settings.scanCentralCustomFortifyRulepacks);
    }
    if (settings_1.settings.scanCentralRunFortifyUpload) {
        scanCentralRunner.arg('-upload');
        scanCentralRunner.argIf(settings_1.settings.scanCentralFortifyApplicationName, ['-application', settings_1.settings.scanCentralFortifyApplicationName]);
        scanCentralRunner.argIf(settings_1.settings.scanCentralFortifyApplicationVersion, ['-version', settings_1.settings.scanCentralFortifyApplicationVersion]);
        scanCentralRunner.argIf(settings_1.settings.scanCentralFortifyApplicationVersionId, ['-versionid', settings_1.settings.scanCentralFortifyApplicationVersionId]);
        scanCentralRunner.arg('-uptoken');
        scanCentralRunner.arg(sscCiToken);
    }
    scanCentralRunner.arg("-scan");
    if (settings_1.settings.scanCentralAdditionalScanParams) {
        scanCentralRunner.line(settings_1.settings.scanCentralAdditionalScanParams);
    }
    logCommand(scanCentralRunner);
    let ret = scanCentralRunner.execSync({ "failOnStdErr": true, "cwd": path.dirname(scancentralPath) });
    if (ret.code === 0) {
        for (let line of ret.stdout.split(/\r\n|\n/)) {
            if (line.includes('Submitted job and received token:')) {
                let strs = line.trim().split(':');
                if (strs.length === 2) {
                    return strs[1].trim();
                }
            }
        }
    }
    else {
        handleErrors(ret);
    }
}
function pollArtifactStateForScanCentral(jobToken) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!jobToken) {
            throw new Error('Failed to retrieve Job Token');
        }
        const scCtrlUrl = yield getScanCentralCtrlUrl();
        const scClientToken = yield getClientAuthToken();
        const endpoint = scCtrlUrl + `/rest/v3/job/${jobToken}/status`;
        let processing = true;
        while (processing) {
            const response = yield node_fetch_1.default(endpoint, {
                method: 'GET',
                headers: {
                    'fortify-client': scClientToken
                }
            });
            if (response.ok) {
                const result = yield response.text();
                const json = yield parseXml(result);
                const state = json.stateResponse.sscUploadState;
                switch (state) {
                    case 'COMPLETED':
                        processing = false;
                        break;
                    case 'CANCELED':
                    case 'FAILED':
                    case 'FAULTED':
                    case 'TIMEOUT':
                        tl.error(`SSC Upload State: ${state}`);
                        throw new Error('Failed to upload analysis results to SSC');
                    default:
                        break;
                }
                if (processing) {
                    yield sleep(1);
                }
            }
            else {
                if (response.status === 404) {
                    tl.error('Build failure criteria is supported in ScanCentral 22.1.0 and later');
                }
                else {
                    tl.error(`Response status: ${response.status}`);
                    const result = yield response.text();
                    const json = yield parseXml(result);
                    tl.error(JSON.stringify(json));
                }
                throw new Error('Failed to get Job Status');
            }
        }
        let timeoutInMinutes = parseInt(settings_1.settings.timeoutForPollingArtifactState);
        if (!timeoutInMinutes) {
            timeoutInMinutes = 0;
        }
        const timeoutInMills = timeoutInMinutes * 60 * 1000;
        const timeout = timeoutInMills === 0 ? 0 : new Date().getTime() + timeoutInMills;
        let interval = parseInt(settings_1.settings.intervalForPollingArtifactState);
        if (!interval) {
            interval = 1;
        }
        processing = true;
        while (processing) {
            const response = yield node_fetch_1.default(endpoint, {
                method: 'GET',
                headers: {
                    'fortify-client': scClientToken
                }
            });
            if (response.ok) {
                const result = yield response.text();
                const json = yield parseXml(result);
                const state = json.stateResponse.sscArtifactState;
                processing = yield checkState(state, processing, timeout, interval);
            }
            else {
                if (response.status === 404) {
                    tl.error('Build failure criteria is supported in ScanCentral 22.1.0 and later');
                }
                else {
                    tl.error(`Response status: ${response.status}`);
                    const result = yield response.text();
                    const json = yield parseXml(result);
                    tl.error(JSON.stringify(json));
                }
                throw new Error('Failed to get Job Status');
            }
        }
    });
}
function checkState(state, processing, timeout, interval) {
    return __awaiter(this, void 0, void 0, function* () {
        switch (state) {
            case 'SCHED_PROCESSING':
            case 'PROCESSING':
                break;
            case 'PROCESS_COMPLETE':
                processing = false;
                break;
            case 'REQUIRE_AUTH':
                console.warn('The artifact needs to be approved for processing in SSC');
                break;
            default:
                throw new Error(`SSC failed to process the artifact: ${state}`);
        }
        if (processing) {
            if (timeout === 0) {
                yield sleep(interval);
            }
            else {
                const current = new Date().getTime();
                if (timeout > current) {
                    yield sleep(interval);
                }
                else {
                    throw new TimeoutError('Timeout for polling SSC expired');
                }
            }
        }
        return processing;
    });
}
function getScanCentralCtrlUrl() {
    return __awaiter(this, void 0, void 0, function* () {
        sscCiToken = settings_1.settings.fortifyAuth;
        let endpoint = trimUrl(settings_1.settings.sscUrl) + '/api/v1/cloudsystem/settings';
        const fortifyToken = uuid.validate(sscCiToken) ? buffer_1.Buffer.from(sscCiToken).toString('base64') : sscCiToken;
        const authHeader = 'FortifyToken ' + fortifyToken;
        const response = yield node_fetch_1.default(endpoint, {
            method: 'GET',
            agent: proxyAgent,
            headers: {
                'Authorization': authHeader
            }
        });
        if (response.ok) {
            const json = yield response.json();
            return trimUrl(json.data.controllerSystemUrl);
        }
        else {
            tl.error(`Response status: ${response.status}`);
            tl.error(yield response.text());
            throw new Error('Failed to get ScanCentral Controller URL');
        }
    });
}
function getClientAuthToken() {
    return __awaiter(this, void 0, void 0, function* () {
        const installRoot = path.dirname(path.dirname(settings_1.settings.scanCentralExe));
        const clientPropFile = installRoot + path.sep + 'Core/config/client.properties';
        const properties = propertiesReader(clientPropFile);
        return properties.get('client_auth_token').toString();
    });
}
function getProjectVersionIdForScanCentral() {
    return __awaiter(this, void 0, void 0, function* () {
        sscCiToken = settings_1.settings.fortifyAuth;
        if (settings_1.settings.scanCentralFortifyApplicationVersionId) {
            return parseInt(settings_1.settings.scanCentralFortifyApplicationVersionId);
        }
        else {
            let endpoint = trimUrl(settings_1.settings.sscUrl)
                + `/api/v1/cloudmappings/mapByVersionName?projectName=${settings_1.settings.scanCentralFortifyApplicationName}&projectVersionName=${settings_1.settings.scanCentralFortifyApplicationVersion}`;
            const fortifyToken = uuid.validate(sscCiToken) ? buffer_1.Buffer.from(sscCiToken).toString('base64') : sscCiToken;
            const authHeader = 'FortifyToken ' + fortifyToken;
            const response = yield node_fetch_1.default(endpoint, {
                method: 'GET',
                agent: proxyAgent,
                headers: {
                    'Authorization': authHeader
                }
            });
            if (response.ok) {
                const json = yield response.json();
                return parseInt(json.data.projectVersionId);
            }
            else {
                tl.error(`Response status: ${response.status}`);
                tl.error(yield response.text());
                throw new Error('Failed to get application version ID');
            }
        }
    });
}
function logCommand(toolRunner) {
    var command = `${toolRunner.toolPath} `;
    var previousArg = null;
    for (let arg of toolRunner.args) {
        if (previousArg !== null && (previousArg === '-uptoken' || previousArg === '-ssctoken')) {
            command += `******** `;
        }
        else {
            command += `${arg} `;
        }
        previousArg = arg;
    }
    console.log(command);
}
function runFortifyLocalScan() {
    return __awaiter(this, void 0, void 0, function* () {
        runScanCommand();
        if (settings_1.settings.runFortifyUpload && tl.exist(settings_1.settings.scanFilePath)) {
            const artifactId = yield uploadFPR();
            if (settings_1.settings.fortifyBuildFailureCriteria) {
                yield pollArtifactState(artifactId);
                yield calcStats(settings_1.settings.fortifyBuildFailureCriteria);
            }
        }
    });
}
function runScanCommand() {
    let sca = getAnalyzer();
    if (settings_1.settings.additionalScanParams) {
        sca.line(settings_1.settings.additionalScanParams);
    }
    if (settings_1.settings.hasRulePackPath) {
        sca.arg('-rules');
        sca.arg(settings_1.settings.customFortifyRulepacks);
    }
    sca.arg('-logfile');
    sca.arg(settings_1.settings.scanLogFile);
    sca.arg('-scan');
    sca.arg('-f');
    sca.arg(settings_1.settings.scanFilePath);
    handleErrors(sca.execSync({ "failOnStdErr": true, "cwd": path.dirname(settings_1.settings.scaExe) }));
}
function uploadFPR() {
    return __awaiter(this, void 0, void 0, function* () {
        sscCiToken = yield getSscToken();
        projectVersionId = yield getProjectVersionId();
        return yield uploadArtifact();
    });
}
function getSscToken() {
    return __awaiter(this, void 0, void 0, function* () {
        if (settings_1.settings.fortifyAuthUser) {
            const endpoint = trimUrl(settings_1.settings.sscUrl) + '/api/v1/tokens';
            const expirationPeriod = 10;
            let date = new Date();
            date.setDate(date.getDate() + expirationPeriod);
            const data = {
                description: "Azure DevOps Extension - SCA Assessment Task",
                terminalDate: date.toISOString(),
                type: "CIToken"
            };
            const response = yield node_fetch_1.default(endpoint, {
                method: 'POST',
                body: JSON.stringify(data),
                agent: proxyAgent,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Basic ' + buffer_1.Buffer.from(`${settings_1.settings.fortifyAuthUser}:${settings_1.settings.fortifyAuth}`).toString('base64')
                }
            });
            if (response.ok) {
                const json = yield response.json();
                tokenId = json.data.id;
                return json.data.token;
            }
            else {
                tl.error(`Response status: ${response.status}`);
                tl.error(yield response.text());
                throw new Error('Failed to generate temporary SSC token');
            }
        }
        else {
            return settings_1.settings.fortifyAuth;
        }
    });
}
function getProjectVersionId() {
    return __awaiter(this, void 0, void 0, function* () {
        if (settings_1.settings.fortifyApplicationVersionId) {
            return parseInt(settings_1.settings.fortifyApplicationVersionId);
        }
        else {
            const endpoint = trimUrl(settings_1.settings.sscUrl)
                + `/api/v1/projectVersions?fields=id&q=project.name:"${settings_1.settings.fortifyApplicationName}"%2BAND%2Bname:"${settings_1.settings.fortifyApplicationVersion}"`;
            const fortifyToken = uuid.validate(sscCiToken) ? buffer_1.Buffer.from(sscCiToken).toString('base64') : sscCiToken;
            const authHeader = 'FortifyToken ' + fortifyToken;
            const response = yield node_fetch_1.default(endpoint, {
                method: 'GET',
                agent: proxyAgent,
                headers: {
                    'Authorization': authHeader
                }
            });
            if (response.ok) {
                const json = yield response.json();
                if (json.data.length === 1) {
                    return parseInt(json.data[0].id);
                }
                else {
                    throw new Error('Unable to find the specified application name and version');
                }
            }
            else {
                tl.error(`Response status: ${response.status}`);
                tl.error(yield response.text());
                throw new Error('Failed to get application version ID');
            }
        }
    });
}
function uploadArtifact() {
    return __awaiter(this, void 0, void 0, function* () {
        const endpoint = trimUrl(settings_1.settings.sscUrl) + `/api/v1/projectVersions/${projectVersionId}/artifacts`;
        const fileStream = fs.createReadStream(settings_1.settings.scanFilePath);
        const form = new FormData();
        form.append('file', fileStream);
        const fortifyToken = uuid.validate(sscCiToken) ? buffer_1.Buffer.from(sscCiToken).toString('base64') : sscCiToken;
        const authHeader = 'FortifyToken ' + fortifyToken;
        console.log(`Uploading ${settings_1.settings.scanFilePath} to ${settings_1.settings.sscUrl}`);
        const response = yield node_fetch_1.default(endpoint, {
            method: 'POST',
            agent: proxyAgent,
            body: form,
            headers: {
                'Authorization': authHeader
            }
        });
        if (response.ok) {
            console.log('Background submission succeeded');
            const json = yield response.json();
            return parseInt(json.data.id);
        }
        else {
            tl.error(`Response status: ${response.status}`);
            tl.error(yield response.text());
            throw new Error('Failed to upload FPR to SSC');
        }
    });
}
function pollArtifactState(id) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!id) {
            throw new Error('Failed to get artifact Id');
        }
        let endpoint = trimUrl(settings_1.settings.sscUrl) + `/api/v1/artifacts/${id}`;
        let timeoutInMinutes = parseInt(settings_1.settings.timeoutForPollingArtifactState);
        if (!timeoutInMinutes) {
            timeoutInMinutes = 0;
        }
        const timeoutInMills = timeoutInMinutes * 60 * 1000;
        const timeout = timeoutInMills === 0 ? 0 : new Date().getTime() + timeoutInMills;
        let interval = parseInt(settings_1.settings.intervalForPollingArtifactState);
        if (!interval) {
            interval = 1;
        }
        let processing = true;
        const fortifyToken = uuid.validate(sscCiToken) ? buffer_1.Buffer.from(sscCiToken).toString('base64') : sscCiToken;
        const authHeader = 'FortifyToken ' + fortifyToken;
        while (processing) {
            const response = yield node_fetch_1.default(endpoint, {
                method: 'GET',
                agent: proxyAgent,
                headers: {
                    'Authorization': authHeader
                }
            });
            if (response.ok) {
                const json = yield response.json();
                let state = json.data.status;
                processing = yield checkState(state, processing, timeout, interval);
            }
            else {
                if (response.status === 404) {
                    tl.error('Build failure criteria is supported in ScanCentral 22.1.0 and later');
                }
                else {
                    tl.error(`Response status: ${response.status}`);
                    tl.error(yield response.text());
                }
                throw new Error('Failed to get Job Status');
            }
        }
    });
}
function parseXml(xml) {
    return new Promise((resolve, reject) => {
        const parser = new xml2js.Parser({ trim: true, explicitArray: false });
        parser.parseString(xml, (error, result) => {
            if (error) {
                reject(error);
            }
            else {
                resolve(result);
            }
        });
    });
}
function calcStats(buildFailureCriteria) {
    return __awaiter(this, void 0, void 0, function* () {
        let defaultFilterSet = yield getDefaultFilterSet();
        let issueFolder = yield getIssueGroupFolders(defaultFilterSet.guid, buildFailureCriteria);
        if (issueFolder.length) {
            let totalCount = 0;
            issueFolder.forEach((issue) => { totalCount += issue.totalCount; });
            throw new BuildFailureError('Build failure criteria matches. Total count: ' + totalCount);
        }
    });
}
function deleteTempToken() {
    return __awaiter(this, void 0, void 0, function* () {
        if (tokenId) {
            let endpoint = trimUrl(settings_1.settings.sscUrl) + `/api/v1/tokens/${tokenId}`;
            const response = yield node_fetch_1.default(endpoint, {
                method: 'DELETE',
                agent: proxyAgent,
                headers: {
                    'Authorization': 'Basic ' + buffer_1.Buffer.from(`${settings_1.settings.fortifyAuthUser}:${settings_1.settings.fortifyAuth}`).toString('base64')
                }
            });
            if (!response.ok) {
                console.warn(`Failed to delete auth token: ${response.status}`);
            }
            tokenId = null;
        }
    });
}
function sleep(mins) {
    const ms = mins * 60 * 1000;
    return new Promise(resolve => setTimeout(resolve, ms));
}
function getDefaultFilterSet() {
    return __awaiter(this, void 0, void 0, function* () {
        let endpoint = trimUrl(settings_1.settings.sscUrl) + `/api/v1/projectVersions/${projectVersionId}/filterSets`;
        const fortifyToken = uuid.validate(sscCiToken) ? buffer_1.Buffer.from(sscCiToken).toString('base64') : sscCiToken;
        const authHeader = 'FortifyToken ' + fortifyToken;
        const response = yield node_fetch_1.default(endpoint, {
            method: 'GET',
            agent: proxyAgent,
            headers: {
                'Authorization': authHeader
            }
        });
        if (response.ok) {
            const json = yield response.json();
            for (const filterSet of json.data) {
                if (filterSet.defaultFilterSet) {
                    return filterSet;
                }
            }
            throw new Error('Failed to get Default FilterSet');
        }
        else {
            tl.error(`Response status: ${response.status}`);
            tl.error(yield response.text());
            throw new Error('Failed to get Default FilterSet');
        }
    });
}
function getIssueGroupFolders(filterSetGuid, searchCondition) {
    return __awaiter(this, void 0, void 0, function* () {
        let endpoint = trimUrl(settings_1.settings.sscUrl) + `/api/v1/projectVersions/${projectVersionId}/issueGroups`;
        const params = { qm: 'issues', q: `${searchCondition}`, filterset: `${filterSetGuid}`, groupingtype: 'FOLDER' };
        const query = new URLSearchParams(params);
        const fortifyToken = uuid.validate(sscCiToken) ? buffer_1.Buffer.from(sscCiToken).toString('base64') : sscCiToken;
        const authHeader = 'FortifyToken ' + fortifyToken;
        const response = yield node_fetch_1.default(endpoint + '?' + query, {
            method: 'GET',
            agent: proxyAgent,
            headers: {
                'Authorization': authHeader
            }
        });
        if (response.ok) {
            const json = yield response.json();
            return json.data;
        }
        else {
            const msg = `Failed to retrieve issue groups for the application version ID: ${projectVersionId}`;
            tl.error(msg);
            tl.error(`Response status: ${response.status}`);
            tl.error(yield response.text());
            throw new Error(msg);
        }
    });
}
function trimUrl(url) {
    url = url.trim();
    if (url.endsWith('/')) {
        url = url.substring(0, url.length - 1);
    }
    return url;
}
class FilterSet {
}
class Folder {
}
class IssueFolder {
}
class TimeoutError extends Error {
    constructor(message) {
        super(message);
    }
}
class BuildFailureError extends Error {
    constructor(message) {
        super(message);
    }
}
run();
