import * as path from "path";
import * as process from "process";
import * as tl from "azure-pipelines-task-lib/task";
import * as os from "os";
import * as fs from "fs";
import * as fg from "fast-glob";

//Sets the location of the resources json. This is typically the task.json file. Call once at the beginning of the script before any calls to loc.
tl.setResourcePath(path.join(__dirname, 'task.json'));//taken from https://github.com/Microsoft/vsts-tasks/blob/master/Tasks/Npm/npmtask.ts
var validationErrors = [];
const isWindows = os.platform().startsWith('win');
const fortifyInstallRoot = isWindows ? process.env['SystemDrive'] + path.sep + 'Fortify' : process.env['HOME'] + path.sep + 'Fortify';
const scaInstallationDir = path.resolve(fortifyInstallRoot, 'Fortify_SCA_and_Apps');
const scaInstallationBinDir = path.resolve(scaInstallationDir, 'bin');

tl.debug("SCA base path: "+scaInstallationDir);

function getPathFor(exec) {
    try {
        return tl.which(exec, true);
    } catch(e) {
        prependPath(scaInstallationBinDir);
        return path.resolve(scaInstallationBinDir, exec);
    }
}

function prependPath(toolPath: string) {
    let pathEnv: string = process.env['PATH'];
    let paths: string[] = pathEnv.split(path.delimiter);
    if (paths.indexOf(toolPath) === -1) {
        let newPath: string = toolPath + path.delimiter + process.env['PATH'];
        process.env['PATH'] = newPath;
    }
}

const applicationType = tl.getInput('applicationType',true);
var settings = {
    artifactDir:tl.getVariable('Build.ArtifactStagingDirectory'),
    sourceBase:tl.getVariable('Build.Repository.LocalPath'),
    buildId:tl.getVariable('Build.BuildId'),
    buildNumber:tl.getVariable('Build.BuildNumber'),
    scaUpdateExe: getPathFor("fortifyupdate"),
    scaExe: getPathFor("sourceanalyzer"),
    clientExe: getPathFor("fortifyclient"),
    scanCentralExe: getPathFor("scancentral"),
    cloudscanExe: getPathFor("cloudscan"),
    devenvExe: tl.getInput("devenvExe"),
    applicationType: applicationType,//The type of application to be analyzed.
    runBuildTranslate:tl.getBoolInput('runBuildTranslate'),//If checked, will run the Build (translate) step.
    licenseFile: tl.getInput('licenseFile'),
    fortifyProjects:tl.getPathInput('fortifyProjects',true),//The relative path to the project or solution to scan. Wildcards can be used. For example, `**\*.sln` for all sln files in all sub folders.
    buildAnalyzerParams:tl.getInput('buildAnalyzerParams'),//Additional parameters to pass to source analyzer during the translation process
    additionalScanParams:tl.getInput('additionalScanParams'),
    buildToolOptions:tl.getInput('buildToolOptions'),//These options are used when integrating Micro Focus Security Fortify SCA with a compiler.
    fortifySourceTranslate:tl.getInput('fortifySourceTranslate'),//Expressions denoting a file or a group of files (one per line), optionally matching a pattern. For example, path/file1.java - a single file, path/file*.java - files matching an expression, path/**/*.java - recursive expression matches. Paths are relative to the project root.
    fortifyOtherTranslate:tl.getInput('fortifyOtherTranslate'),//A translation step for miscellaneous files.
    fortifyBuildId:tl.getInput('fortifyBuildId',true),//A build ID for the Scan to use. If one is not provided, a random GUID will be generated for this invocation.
    runFortifyRulepackUpdate:tl.getBoolInput('runFortifyRulepackUpdate'),//If checked, will run the Fortify Rulepack Update step.
    runFortifyClean:tl.getBoolInput('runFortifyClean'),//If checked, will run the Fortify SCA CLEAN step.
    scaVerbose:tl.getBoolInput('scaVerbose'),
    scaDebug:tl.getBoolInput('scaDebug'),
    runFortifyScan:tl.getBoolInput('runFortifyScan'),//If checked, scan will run and user will select the scan type.
    fortifyScanType:tl.getInput('fortifyScanType'),//Select between running a Local scan or ScanCentral scan
    customFortifyRulepacks:tl.getPathInput('customFortifyRulepacks'),//Additional custom rulepacks to be used for the local scan.
    hasRulePackPath:tl.filePathSupplied('customFortifyRulepacks'),
    runFortifyUpload:tl.getBoolInput('runFortifyUpload'),//If checked, will upload your local scan results to a Fortify SSC server.
    fortifyServerName:tl.getInput('fortifyServerName'),//The name of the Service connection on your Azure DevOps project configured to the Fortify SSC Server where results will be uploaded.
    fortifyApplicationName:tl.getInput('fortifyApplicationName'),//The Application Name configured on the Fortify SSC Server.
    fortifyApplicationVersion:tl.getInput('fortifyApplicationVersion'),//The Application Version configured on the Fortify SSC Server.
    fortifyApplicationVersionId:tl.getInput('fortifyApplicationVersionId'), // The Application Version ID configured on the Fortify SSC Server.
    fortifyBuildFailureCriteria:tl.getInput('fortifyBuildFailureCriteria'), // The build failure criteria
    taskResultForBuildFailureCriteria:tl.getInput('taskResultForBuildFailureCriteria'), // Task result when build failure criteria is met
    timeoutForPollingArtifactState:tl.getInput('timeoutForPollingArtifactState'), // Timeout for polling artifact state
    intervalForPollingArtifactState:tl.getInput('intervalForPollingArtifactState'), // Interval for polling artifact state
    buildClasspath:tl.getInput('buildClasspath'),
    buildSourceVersion:tl.getInput('buildSourceVersion'),
    buildSourcePath:tl.getInput('buildSourcePath'),
    uploadProxyURL:tl.getInput('uploadProxyURL'),
    uploadProxyUser:tl.getInput('uploadProxyUser'),
    uploadProxyPass:tl.getInput('uploadProxyPass'),
    scanCentralAdditionalScanParams:tl.getInput('scanCentralAdditionalScanParams'),
    scanCentralCustomFortifyRulepacks:tl.getPathInput('scanCentralCustomFortifyRulepacks'),//Additional custom rulepacks to be used for the ScanCentral.
    scanCentralHasRulePackPath:tl.filePathSupplied('scanCentralCustomFortifyRulepacks'),
    scanCentralFortifyServerName:tl.getInput('scanCentralFortifyServerName'),//SSC Endpoint used to get the controller URL or upload scan results if checked. Using ScanCentral
    scanCentralRunFortifyUpload:tl.getBoolInput('scanCentralRunFortifyUpload'),//If checked, will upload your ScanCentral results to a Fortify SSC server.
    scanCentralFortifyApplicationName:tl.getInput('scanCentralFortifyApplicationName'),//The Application name configured on the Fortify SSC Server.
    scanCentralFortifyApplicationVersion:tl.getInput('scanCentralFortifyApplicationVersion'),//The Application version configured on the Fortify SSC Server.
    scanCentralFortifyApplicationVersionId:tl.getInput('scanCentralFortifyApplicationVersionId'),//The Application version ID configured on the Fortify SSC Server.
    sscUrl:'',
    fortifyAuthType:'',
    fortifyAuth:'',
    fortifyAuthUser:'',
    buildLogFile:'',
    scanLogFile:'',
    scaArtifactsDir:'',
    scanFilePath:'',
    isDotNet: applicationType === 'dotnet',
    isOther: applicationType === 'other',
    isJava: applicationType === 'java',
    validate:function validate() {
        if(!isWindows && this.isDotNet) {
          validationErrors.push("Unable to scan .NET project on Linux agent");
        }
        if(this.isDotNet){
            var files = fg.sync(this.fortifyProjects.replace(/\\/g, '/'));
            if(!files || files.length === 0){
                validationErrors.push(`No files to process for translation, check the 'Projects for Fortify SCA Analysis' setting`); //todo move to resource file
            }
        }
        if(settings.licenseFile && !fs.existsSync(settings.licenseFile)) {
          validationErrors.push(`License file ${settings.licenseFile} does not exist`);
        }
        if(!fs.existsSync(settings.scaExe)) {
            validationErrors.push(tl.loc('version.failure'));
        }
        let timeoutInMinutes: number = parseInt(settings.timeoutForPollingArtifactState);
        if (timeoutInMinutes < 0 || timeoutInMinutes > 10080) {
            validationErrors.push('Invalid timeout value specified to wait until SSC has processed the FPR');
        }
        let interval: number = parseInt(settings.intervalForPollingArtifactState);
        if (interval < 1 || interval > 60) {
            validationErrors.push('Invalid interval value specified for how often to check if SSC has processed the FPR');
        }

        return validationErrors;
    }
};
settings.scaArtifactsDir = path.join(settings.artifactDir,'sca_artifacts');
settings.fortifyBuildId = settings.fortifyBuildId.replace(/ /g,'_');
settings.scanFilePath = path.join(settings.scaArtifactsDir, settings.fortifyBuildId + '.fpr');

if(settings.runFortifyScan){
    if(settings.fortifyScanType == 'ScanCentralScan'){
        // ScanCentral SSC settings
        if (settings.scanCentralFortifyServerName !== null) {
            settings.sscUrl = tl.getEndpointUrl(settings.scanCentralFortifyServerName, false);
            var auth = tl.getEndpointAuthorization(settings.scanCentralFortifyServerName, false);
            settings.fortifyAuth = auth.parameters['password'];
            if(!settings.fortifyAuth){
                validationErrors.push(tl.loc('conditionalFieldRequirement',tl.loc("password"), "Running ScanCentral scan"));
            }
            settings.fortifyAuthUser = auth.parameters['username'];
            settings.fortifyAuthType = auth.scheme;
        }else{
            validationErrors.push(tl.loc('conditionalFieldRequirement',"Fortify SSC Server service connection","Running ScanCentral scan"));
        }
    }else if(settings.fortifyScanType == 'LocalScan'){
        // LocalScan SSC settings
        if(settings.runFortifyUpload){
            if (settings.fortifyServerName !== null) {
                settings.sscUrl = tl.getEndpointUrl(settings.fortifyServerName, false);
                var auth = tl.getEndpointAuthorization(settings.fortifyServerName, false);
                settings.fortifyAuth = auth.parameters['password'];
                if(!settings.fortifyAuth){
                    validationErrors.push(tl.loc('conditionalFieldRequirement',tl.loc("password"), "Uploading results to SSC"));
                }
                settings.fortifyAuthUser = auth.parameters['username'];
                settings.fortifyAuthType = auth.scheme;
            } else {
                validationErrors.push(tl.loc('conditionalFieldRequirement',"Fortify SSC Server service connection","Uploading results to SSC"));
            }
        }
    }
}

settings.buildLogFile = path.join(settings.scaArtifactsDir,settings.fortifyBuildId+'_build.log');
settings.scanLogFile = path.join(settings.scaArtifactsDir,settings.fortifyBuildId+'_scan.log');
tl.debug(JSON.stringify(settings));
export { settings };
