"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settings = void 0;
const path = require("path");
const process = require("process");
const tl = require("azure-pipelines-task-lib/task");
const os = require("os");
const fs = require("fs");
const fg = require("fast-glob");
tl.setResourcePath(path.join(__dirname, 'task.json'));
var validationErrors = [];
const isWindows = os.platform().startsWith('win');
const fortifyInstallRoot = isWindows ? process.env['SystemDrive'] + path.sep + 'Fortify' : process.env['HOME'] + path.sep + 'Fortify';
const scaInstallationDir = path.resolve(fortifyInstallRoot, 'Fortify_SCA_and_Apps');
const scaInstallationBinDir = path.resolve(scaInstallationDir, 'bin');
tl.debug("SCA base path: " + scaInstallationDir);
function getPathFor(exec) {
    try {
        return tl.which(exec, true);
    }
    catch (e) {
        prependPath(scaInstallationBinDir);
        return path.resolve(scaInstallationBinDir, exec);
    }
}
function prependPath(toolPath) {
    let pathEnv = process.env['PATH'];
    let paths = pathEnv.split(path.delimiter);
    if (paths.indexOf(toolPath) === -1) {
        let newPath = toolPath + path.delimiter + process.env['PATH'];
        process.env['PATH'] = newPath;
    }
}
const applicationType = tl.getInput('applicationType', true);
var settings = {
    artifactDir: tl.getVariable('Build.ArtifactStagingDirectory'),
    sourceBase: tl.getVariable('Build.Repository.LocalPath'),
    buildId: tl.getVariable('Build.BuildId'),
    buildNumber: tl.getVariable('Build.BuildNumber'),
    scaUpdateExe: getPathFor("fortifyupdate"),
    scaExe: getPathFor("sourceanalyzer"),
    clientExe: getPathFor("fortifyclient"),
    scanCentralExe: getPathFor("scancentral"),
    cloudscanExe: getPathFor("cloudscan"),
    devenvExe: tl.getInput("devenvExe"),
    applicationType: applicationType,
    runBuildTranslate: tl.getBoolInput('runBuildTranslate'),
    licenseFile: tl.getInput('licenseFile'),
    fortifyProjects: tl.getPathInput('fortifyProjects', true),
    buildAnalyzerParams: tl.getInput('buildAnalyzerParams'),
    additionalScanParams: tl.getInput('additionalScanParams'),
    buildToolOptions: tl.getInput('buildToolOptions'),
    fortifySourceTranslate: tl.getInput('fortifySourceTranslate'),
    fortifyOtherTranslate: tl.getInput('fortifyOtherTranslate'),
    fortifyBuildId: tl.getInput('fortifyBuildId', true),
    runFortifyRulepackUpdate: tl.getBoolInput('runFortifyRulepackUpdate'),
    runFortifyClean: tl.getBoolInput('runFortifyClean'),
    scaVerbose: tl.getBoolInput('scaVerbose'),
    scaDebug: tl.getBoolInput('scaDebug'),
    runFortifyScan: tl.getBoolInput('runFortifyScan'),
    fortifyScanType: tl.getInput('fortifyScanType'),
    customFortifyRulepacks: tl.getPathInput('customFortifyRulepacks'),
    hasRulePackPath: tl.filePathSupplied('customFortifyRulepacks'),
    runFortifyUpload: tl.getBoolInput('runFortifyUpload'),
    fortifyServerName: tl.getInput('fortifyServerName'),
    fortifyApplicationName: tl.getInput('fortifyApplicationName'),
    fortifyApplicationVersion: tl.getInput('fortifyApplicationVersion'),
    fortifyApplicationVersionId: tl.getInput('fortifyApplicationVersionId'),
    fortifyBuildFailureCriteria: tl.getInput('fortifyBuildFailureCriteria'),
    taskResultForBuildFailureCriteria: tl.getInput('taskResultForBuildFailureCriteria'),
    timeoutForPollingArtifactState: tl.getInput('timeoutForPollingArtifactState'),
    intervalForPollingArtifactState: tl.getInput('intervalForPollingArtifactState'),
    buildClasspath: tl.getInput('buildClasspath'),
    buildSourceVersion: tl.getInput('buildSourceVersion'),
    buildSourcePath: tl.getInput('buildSourcePath'),
    uploadProxyURL: tl.getInput('uploadProxyURL'),
    uploadProxyUser: tl.getInput('uploadProxyUser'),
    uploadProxyPass: tl.getInput('uploadProxyPass'),
    scanCentralAdditionalScanParams: tl.getInput('scanCentralAdditionalScanParams'),
    scanCentralCustomFortifyRulepacks: tl.getPathInput('scanCentralCustomFortifyRulepacks'),
    scanCentralHasRulePackPath: tl.filePathSupplied('scanCentralCustomFortifyRulepacks'),
    scanCentralFortifyServerName: tl.getInput('scanCentralFortifyServerName'),
    scanCentralRunFortifyUpload: tl.getBoolInput('scanCentralRunFortifyUpload'),
    scanCentralFortifyApplicationName: tl.getInput('scanCentralFortifyApplicationName'),
    scanCentralFortifyApplicationVersion: tl.getInput('scanCentralFortifyApplicationVersion'),
    scanCentralFortifyApplicationVersionId: tl.getInput('scanCentralFortifyApplicationVersionId'),
    sscUrl: '',
    fortifyAuthType: '',
    fortifyAuth: '',
    fortifyAuthUser: '',
    buildLogFile: '',
    scanLogFile: '',
    scaArtifactsDir: '',
    scanFilePath: '',
    isDotNet: applicationType === 'dotnet',
    isOther: applicationType === 'other',
    isJava: applicationType === 'java',
    validate: function validate() {
        if (!isWindows && this.isDotNet) {
            validationErrors.push("Unable to scan .NET project on Linux agent");
        }
        if (this.isDotNet) {
            var files = fg.sync(this.fortifyProjects.replace(/\\/g, '/'));
            if (!files || files.length === 0) {
                validationErrors.push(`No files to process for translation, check the 'Projects for Fortify SCA Analysis' setting`);
            }
        }
        if (settings.licenseFile && !fs.existsSync(settings.licenseFile)) {
            validationErrors.push(`License file ${settings.licenseFile} does not exist`);
        }
        if (!fs.existsSync(settings.scaExe)) {
            validationErrors.push(tl.loc('version.failure'));
        }
        let timeoutInMinutes = parseInt(settings.timeoutForPollingArtifactState);
        if (timeoutInMinutes < 0 || timeoutInMinutes > 10080) {
            validationErrors.push('Invalid timeout value specified to wait until SSC has processed the FPR');
        }
        let interval = parseInt(settings.intervalForPollingArtifactState);
        if (interval < 1 || interval > 60) {
            validationErrors.push('Invalid interval value specified for how often to check if SSC has processed the FPR');
        }
        return validationErrors;
    }
};
exports.settings = settings;
settings.scaArtifactsDir = path.join(settings.artifactDir, 'sca_artifacts');
settings.fortifyBuildId = settings.fortifyBuildId.replace(/ /g, '_');
settings.scanFilePath = path.join(settings.scaArtifactsDir, settings.fortifyBuildId + '.fpr');
if (settings.runFortifyScan) {
    if (settings.fortifyScanType == 'ScanCentralScan') {
        if (settings.scanCentralFortifyServerName !== null) {
            settings.sscUrl = tl.getEndpointUrl(settings.scanCentralFortifyServerName, false);
            var auth = tl.getEndpointAuthorization(settings.scanCentralFortifyServerName, false);
            settings.fortifyAuth = auth.parameters['password'];
            if (!settings.fortifyAuth) {
                validationErrors.push(tl.loc('conditionalFieldRequirement', tl.loc("password"), "Running ScanCentral scan"));
            }
            settings.fortifyAuthUser = auth.parameters['username'];
            settings.fortifyAuthType = auth.scheme;
        }
        else {
            validationErrors.push(tl.loc('conditionalFieldRequirement', "Fortify SSC Server service connection", "Running ScanCentral scan"));
        }
    }
    else if (settings.fortifyScanType == 'LocalScan') {
        if (settings.runFortifyUpload) {
            if (settings.fortifyServerName !== null) {
                settings.sscUrl = tl.getEndpointUrl(settings.fortifyServerName, false);
                var auth = tl.getEndpointAuthorization(settings.fortifyServerName, false);
                settings.fortifyAuth = auth.parameters['password'];
                if (!settings.fortifyAuth) {
                    validationErrors.push(tl.loc('conditionalFieldRequirement', tl.loc("password"), "Uploading results to SSC"));
                }
                settings.fortifyAuthUser = auth.parameters['username'];
                settings.fortifyAuthType = auth.scheme;
            }
            else {
                validationErrors.push(tl.loc('conditionalFieldRequirement', "Fortify SSC Server service connection", "Uploading results to SSC"));
            }
        }
    }
}
settings.buildLogFile = path.join(settings.scaArtifactsDir, settings.fortifyBuildId + '_build.log');
settings.scanLogFile = path.join(settings.scaArtifactsDir, settings.fortifyBuildId + '_scan.log');
tl.debug(JSON.stringify(settings));
