import * as path from "path";
import * as tl from "azure-pipelines-task-lib/task";
import { IExecOptions, ToolRunner } from "azure-pipelines-task-lib/toolrunner";
import * as cp from "child_process";
import * as fs from "fs";
import * as FormData from "form-data";
import fetch from "node-fetch";
import { Buffer } from "buffer";
import * as propertiesReader from "properties-reader";
import * as xml2js from "xml2js";
import * as uuid from "uuid";
import { settings } from "./settings";
const HttpsProxyAgent = require("https-proxy-agent");
const url = require("url");
import * as fg from "fast-glob";

let proxyAgent: string;
let sscCiToken: string;
let projectVersionId: number;
let tokenId: string;

async function run() {
    try {
        let inputErrors = settings.validate();
        if (inputErrors.length) {
            inputErrors.forEach(x => tl.error(x));
            tl.setResult(tl.TaskResult.Failed, "Incorrect settings");
        } else {
            if (settings.licenseFile) {
                const licenseDest = path.join(path.dirname(path.dirname(settings.scaExe)), "fortify.license");
                console.log(`Copying license ${settings.licenseFile} to ${licenseDest}`);
                fs.copyFileSync(settings.licenseFile, licenseDest);
            }
    
            console.log(`Executing ${path.basename(settings.scaExe)} --version to determine if the proper Fortify SCA version is installed`);
            try {
                // Currently, SCA must be in PATH to work, so try to execute just sourceanalyzer --version, without specifying absolute path
                const p = cp.execFileSync(path.basename(settings.scaExe), ['--version']);
                //Micro Focus Fortify Static Code Analyzer 16.11.0002 (using JVM 1.8.0_72)
                let versionMatches = p.toString().match(/([0-9]+)/g);//["16", "11", "0002", "1", "8", "0", "72"]
                let isVersionOk = false;
                if (p.length > 1) {
                    let versionUnity = parseInt(versionMatches[0]);
                    let versionDecimals = parseInt(versionMatches[1]);
                    isVersionOk = (versionUnity == 16 && versionDecimals >= 11) ||
                                    (versionUnity > 16 && versionDecimals >= 10) ||
                                    (versionUnity >= 19 && versionDecimals >= 1);
                }
                if (!isVersionOk) {
                    throw new Error(tl.loc('version.failure'));
                }
            } catch (e) {
                console.log(tl.loc('version.failure'));
                throw e;
            }
        
            if (settings.runFortifyClean) {
                let sca: ToolRunner = getAnalyzer();
                sca.arg('-clean');
                handleErrors(sca.execSync(<IExecOptions>{ "failOnStdErr": true, "cwd": path.dirname(settings.scaExe) }));
            }
        
            if (settings.runFortifyRulepackUpdate) {
                handleErrors(tl.execSync(settings.scaUpdateExe, '', <IExecOptions>{ "failOnStdErr": true }));
            }
        
            if (settings.runBuildTranslate) {
                tl.cd(settings.sourceBase);
                tl.mkdirP(settings.scaArtifactsDir);
                //build/translate
                if (settings.isDotNet) {
                    let solutionFiles = fg.sync(settings.fortifyProjects.replace(/\\/g, '/'));
                    let sca: ToolRunner;
                    solutionFiles.forEach(function (solPath) {
                        solPath = solPath.replace(/\//g, '\\');
                        sca = getAnalyzer();
                        let parts = path.parse(solPath);
                        let logfile = path.join(settings.scaArtifactsDir, parts.base + "_build.log");
                        sca.arg('-logfile');
                        sca.arg(logfile);
                        if (settings.buildAnalyzerParams) {
                            sca.line(settings.buildAnalyzerParams);
                        }
                        sca.arg('devenv');
                        sca.arg(solPath);
                        sca.arg('/REBUILD');
                        sca.arg('DEBUG');
                        handleErrors(sca.execSync(<IExecOptions>{ "failOnStdErr": true, "cwd": path.dirname(settings.scaExe) }));
                    });
                } else {
                    let sca: ToolRunner = getAnalyzer();
                    sca.arg('-logfile');
                    sca.arg(settings.buildLogFile);
                    if (settings.isJava) {
                        if (settings.buildClasspath) {
                            sca.arg('-cp');
                            sca.arg(settings.buildClasspath);
                        }
                        if (settings.buildSourcePath) {
                            sca.arg('-sourcepath');
                            sca.arg(path.join(process.cwd(), settings.buildSourcePath));
                        }
                        sca.arg('-jdk');
                        sca.arg(settings.buildSourceVersion);
                    }
                    if (settings.buildAnalyzerParams) {
                        sca.line(settings.buildAnalyzerParams);
                    }
        
                    let baseSrcArg = process.cwd();
                    if (settings.buildToolOptions) {
                        sca.line(settings.buildToolOptions);
                    } else {
                        if (settings.fortifySourceTranslate) {
                            let sourcesTranslate = settings.fortifySourceTranslate.split('\n');
                            for (let sourceTranslate of sourcesTranslate) {
                                if (sourceTranslate) {
                                    let srcArg = path.join(baseSrcArg, sourceTranslate);
                                    sca.arg(srcArg);
                                }
                            }
                        } else {
                            sca.arg(baseSrcArg);
                        }
        
                        if (settings.fortifyOtherTranslate) {
                            sca.arg(settings.fortifyOtherTranslate);
                        }
                    }
        
                    /*settings.sourceBase for some reason resolves to the job root rather than the source root, so adding the "/s" to
                      make sure the command is run from the source root dir, which is preferred by build tools like Maven, Gradle, etc.*/
                    handleErrors(sca.execSync(<IExecOptions>{ "failOnStdErr": true, "cwd": path.dirname(settings.sourceBase + '/s') }));
                }
            }
        
            if (settings.uploadProxyURL) {
                let proxyOpts: any;
                if (settings.uploadProxyURL.startsWith('http://') || settings.uploadProxyURL.startsWith('https://')) {
                    proxyOpts = url.parse(settings.uploadProxyURL);
                } else {
                    proxyOpts = url.parse('http://' + settings.uploadProxyURL);
                }
                if (settings.uploadProxyUser && settings.uploadProxyPass) {
                    proxyOpts.auth = `${settings.uploadProxyUser}:${settings.uploadProxyPass}`;
                }
                proxyAgent = new HttpsProxyAgent(proxyOpts);
            }
        
            //scan
            if (settings.runFortifyScan) {
                if (settings.fortifyScanType === 'LocalScan') {
                    await runFortifyLocalScan();
                } else if (settings.fortifyScanType === 'ScanCentralScan') {
                    await runFortifyScanCentralScan();
                }
            }
        }
    } catch (err: unknown) {
        if (err instanceof TimeoutError) {
            tl.setResult(tl.TaskResult.SucceededWithIssues, err.message);
        } else if (err instanceof BuildFailureError) {
            let result: string = settings.taskResultForBuildFailureCriteria;
            if (result === 'WARN') {
                tl.setResult(tl.TaskResult.SucceededWithIssues, err.message);
            } else {
                tl.setResult(tl.TaskResult.Failed, err.message);
            }
        } else if (err instanceof Error){
            tl.setResult(tl.TaskResult.Failed, err.message);
        } else {
            tl.setResult(tl.TaskResult.Failed, err.toString());
        }
    } finally {
        await deleteTempToken();
    }
}

function getAnalyzer(): ToolRunner {
    var sca: ToolRunner = tl.tool(path.basename(settings.scaExe));
    sca.arg('-b');
    sca.arg(settings.fortifyBuildId);
    if (settings.scaVerbose) {
        sca.arg('-verbose')
    }
    if (settings.scaDebug) {
        sca.arg('-debug')
    }
    return sca;
}

function handleErrors(retVal) {
    if (retVal.code) {
        throw new Error(`System call exited with status ${retVal.code}`);
    }
}

async function runFortifyScanCentralScan() {
    const jobToken = runScanCentralStartCommand();
    if (settings.scanCentralRunFortifyUpload && settings.fortifyBuildFailureCriteria) {
        await pollArtifactStateForScanCentral(jobToken);
        projectVersionId = await getProjectVersionIdForScanCentral();
        await calcStats(settings.fortifyBuildFailureCriteria);
    }
}

function runScanCentralStartCommand(): string {
    //Get SSC Authorization Token
    sscCiToken = settings.fortifyAuth;

    console.log("INFO: Checking for scancentral executable on PATH.");
    let scancentralPath: string;
    if (fs.existsSync(settings.scanCentralExe)) {
        scancentralPath = settings.scanCentralExe;
    } else {
        console.log("WARNING: Could not find scancentral executable, trying cloudscan instead.");
        scancentralPath = settings.cloudscanExe;
    }
    //start scan
    let scanCentralRunner: ToolRunner = tl.tool(path.basename(scancentralPath));
    scanCentralRunner.arg('-sscurl');
    scanCentralRunner.arg(trimUrl(settings.sscUrl));
    scanCentralRunner.arg('-ssctoken');
    scanCentralRunner.arg(sscCiToken);
    scanCentralRunner.arg('start');
    scanCentralRunner.arg('-b');
    scanCentralRunner.arg(settings.fortifyBuildId);
    if (settings.scanCentralHasRulePackPath) {
        scanCentralRunner.arg('-rules');
        scanCentralRunner.arg(settings.scanCentralCustomFortifyRulepacks);
    }
    if (settings.scanCentralRunFortifyUpload) {
        //upload results
        scanCentralRunner.arg('-upload');
        scanCentralRunner.argIf(settings.scanCentralFortifyApplicationName, ['-application', settings.scanCentralFortifyApplicationName]);
        scanCentralRunner.argIf(settings.scanCentralFortifyApplicationVersion, ['-version', settings.scanCentralFortifyApplicationVersion]);
        scanCentralRunner.argIf(settings.scanCentralFortifyApplicationVersionId, ['-versionid', settings.scanCentralFortifyApplicationVersionId]);
        scanCentralRunner.arg('-uptoken');
        scanCentralRunner.arg(sscCiToken);
    }
    scanCentralRunner.arg("-scan");
    if (settings.scanCentralAdditionalScanParams) {
        scanCentralRunner.line(settings.scanCentralAdditionalScanParams);
    }

    logCommand(scanCentralRunner);

    let ret = scanCentralRunner.execSync(<IExecOptions>{ "failOnStdErr": true, "cwd": path.dirname(scancentralPath) });
    if (ret.code === 0) {
        for (let line of ret.stdout.split(/\r\n|\n/)) {
            if (line.includes('Submitted job and received token:')) {
                let strs: string[] = line.trim().split(':');
                if (strs.length === 2) {
                    return strs[1].trim();
                }
            }
        }
    } else {
        handleErrors(ret);
    }
}

async function pollArtifactStateForScanCentral(jobToken: string): Promise<void> {
    if (!jobToken) {
        throw new Error('Failed to retrieve Job Token');
    }

    const scCtrlUrl = await getScanCentralCtrlUrl();
    const scClientToken = await getClientAuthToken();
    const endpoint = scCtrlUrl + `/rest/v3/job/${jobToken}/status`;

    let processing: boolean = true;
    while (processing) {
        const response = await fetch(endpoint, {
            method: 'GET',
            headers: {
                'fortify-client': scClientToken
            }
        });

        if (response.ok) {
            const result = await response.text();
            const json = await parseXml(result);
            const state = json.stateResponse.sscUploadState;
            switch (state) {
                case 'COMPLETED':
                    processing = false;
                    break;
                case 'CANCELED':
                case 'FAILED':
                case 'FAULTED':
                case 'TIMEOUT':
                    tl.error(`SSC Upload State: ${state}`);
                    throw new Error('Failed to upload analysis results to SSC');
                default:
                    break;
            }
            if (processing) {
                await sleep(1);
            }
        } else {
            if (response.status === 404) {
                tl.error('Build failure criteria is supported in ScanCentral 22.1.0 and later');
            } else {
                tl.error(`Response status: ${response.status}`);
                const result = await response.text();
                const json = await parseXml(result);
                tl.error(JSON.stringify(json));
            }
            throw new Error('Failed to get Job Status');
        }
    }

    let timeoutInMinutes: number = parseInt(settings.timeoutForPollingArtifactState);
    if (!timeoutInMinutes) {
        timeoutInMinutes = 0;
    } 
    const timeoutInMills: number = timeoutInMinutes * 60 * 1000;
    const timeout: number = timeoutInMills === 0 ? 0 : new Date().getTime() + timeoutInMills;
    let interval: number = parseInt(settings.intervalForPollingArtifactState);
    if (!interval) {
        interval = 1;
    }
    processing = true;
    while (processing) {
        const response = await fetch(endpoint, {
            method: 'GET',
            headers: {
                'fortify-client': scClientToken
            }
        });

        if (response.ok) {
            const result = await response.text();
            const json = await parseXml(result);
            const state = json.stateResponse.sscArtifactState;
            processing = await checkState(state, processing, timeout, interval);
        } else {
            if (response.status === 404) {
                tl.error('Build failure criteria is supported in ScanCentral 22.1.0 and later');
            } else {
                tl.error(`Response status: ${response.status}`);
                const result = await response.text();
                const json = await parseXml(result);
                tl.error(JSON.stringify(json));
            }
            throw new Error('Failed to get Job Status');
        }
    }
}

async function checkState(state: string, processing: boolean, timeout: number, interval: number): Promise<boolean> {
    switch (state) {
        case 'SCHED_PROCESSING':
        case 'PROCESSING':
            break;
        case 'PROCESS_COMPLETE':
            processing = false;
            break;
        case 'REQUIRE_AUTH':
            // FIXME: SSC has endpoint to approve FPR processing.
            // Should support this in the future.
            console.warn('The artifact needs to be approved for processing in SSC');
            break;
        default:
            throw new Error(`SSC failed to process the artifact: ${state}`);
    }
    if (processing) {
        if (timeout === 0) {
            await sleep(interval);
        } else {
            const current: number = new Date().getTime();
            if (timeout > current) {
                await sleep(interval);
            } else {
                throw new TimeoutError('Timeout for polling SSC expired');
            }
        }
    }
    return processing;
}

async function getScanCentralCtrlUrl(): Promise<string> {
    sscCiToken = settings.fortifyAuth;
    let endpoint = trimUrl(settings.sscUrl) + '/api/v1/cloudsystem/settings';
    const fortifyToken = uuid.validate(sscCiToken) ? Buffer.from(sscCiToken).toString('base64') : sscCiToken;
    const authHeader = 'FortifyToken ' + fortifyToken;
    const response = await fetch(endpoint, {
        method: 'GET',
        agent: proxyAgent,
        headers: {
            'Authorization' : authHeader
        }
    });

    if (response.ok) {
        const json = await response.json();
        return trimUrl(json.data.controllerSystemUrl);
    } else {
        tl.error(`Response status: ${response.status}`);
        tl.error(await response.text());
        throw new Error('Failed to get ScanCentral Controller URL');
    }
}

async function getClientAuthToken(): Promise<string> {
    const installRoot: string = path.dirname(path.dirname(settings.scanCentralExe));
    const clientPropFile = installRoot + path.sep + 'Core/config/client.properties';
    const properties: propertiesReader.Reader = propertiesReader(clientPropFile);

    return properties.get('client_auth_token').toString();
}

async function getProjectVersionIdForScanCentral(): Promise<number> {
    sscCiToken = settings.fortifyAuth;

    if (settings.scanCentralFortifyApplicationVersionId) {
        return parseInt(settings.scanCentralFortifyApplicationVersionId);
    } else {
        let endpoint = trimUrl(settings.sscUrl)
        + `/api/v1/cloudmappings/mapByVersionName?projectName=${settings.scanCentralFortifyApplicationName}&projectVersionName=${settings.scanCentralFortifyApplicationVersion}`;
        const fortifyToken = uuid.validate(sscCiToken) ? Buffer.from(sscCiToken).toString('base64') : sscCiToken;
        const authHeader = 'FortifyToken ' + fortifyToken;
        const response = await fetch(endpoint, {
            method: 'GET',
            agent: proxyAgent,
            headers: {
                'Authorization' : authHeader
            }
        });
        if (response.ok) {
            const json = await response.json();
            return parseInt(json.data.projectVersionId);
        } else {
            tl.error(`Response status: ${response.status}`);
            tl.error(await response.text());
            throw new Error('Failed to get application version ID');
        }
    }
}

function logCommand(toolRunner: any) {
    //log the command without the value of the used token
    var command = `${toolRunner.toolPath} `;
    var previousArg = null;

    for (let arg of toolRunner.args) {
        if (previousArg !== null && (previousArg === '-uptoken' || previousArg === '-ssctoken')) {
            command += `******** `;
        } else {
            command += `${arg} `;
        }
        previousArg = arg;
    }

    console.log(command);
}

async function runFortifyLocalScan() {
    runScanCommand();

    if (settings.runFortifyUpload && tl.exist(settings.scanFilePath)) {
        const artifactId: number = await uploadFPR();
        if (settings.fortifyBuildFailureCriteria) {
            await pollArtifactState(artifactId);
            await calcStats(settings.fortifyBuildFailureCriteria);
        }
    }
}

function runScanCommand() {
    let sca: ToolRunner = getAnalyzer();

    if (settings.additionalScanParams) {
        sca.line(settings.additionalScanParams);
    }
    if (settings.hasRulePackPath) {
        sca.arg('-rules');
        sca.arg(settings.customFortifyRulepacks);
    }
    sca.arg('-logfile');
    sca.arg(settings.scanLogFile);
    sca.arg('-scan');
    sca.arg('-f');
    sca.arg(settings.scanFilePath);
    handleErrors(sca.execSync(<IExecOptions>{ "failOnStdErr": true, "cwd": path.dirname(settings.scaExe) }));
}

async function uploadFPR(): Promise<number> {
    sscCiToken = await getSscToken();
    projectVersionId = await getProjectVersionId();
    return await uploadArtifact();
}

async function getSscToken(): Promise<string> {
    if (settings.fortifyAuthUser) {
        const endpoint = trimUrl(settings.sscUrl) + '/api/v1/tokens';
        const expirationPeriod: number = 10;
        let date = new Date();
        date.setDate(date.getDate() + expirationPeriod);
        const data = {
            description: "Azure DevOps Extension - SCA Assessment Task",
            terminalDate: date.toISOString(),
            type: "CIToken"
        }
        const response = await fetch(endpoint, {
            method: 'POST',
            body: JSON.stringify(data),
            agent: proxyAgent,
            headers: {
                'Content-Type': 'application/json',
                'Authorization' : 'Basic ' + Buffer.from(`${settings.fortifyAuthUser}:${settings.fortifyAuth}`).toString('base64')
            }
        });

        if (response.ok) {
            const json = await response.json();
            tokenId = json.data.id;  // Store id to delete temp token
            return json.data.token;
        } else {
            tl.error(`Response status: ${response.status}`);
            tl.error(await response.text());
            throw new Error('Failed to generate temporary SSC token');
        }
    } else {
        return settings.fortifyAuth;
    }
}

async function getProjectVersionId(): Promise<number> {

    if (settings.fortifyApplicationVersionId) {
        return parseInt(settings.fortifyApplicationVersionId);
    } else {
        const endpoint = trimUrl(settings.sscUrl) 
        + `/api/v1/projectVersions?fields=id&q=project.name:"${settings.fortifyApplicationName}"%2BAND%2Bname:"${settings.fortifyApplicationVersion}"`;
        const fortifyToken = uuid.validate(sscCiToken) ? Buffer.from(sscCiToken).toString('base64') : sscCiToken;
        const authHeader = 'FortifyToken ' + fortifyToken;
        const response = await fetch(endpoint, {
            method: 'GET',
            agent: proxyAgent,
            headers: {
                'Authorization' : authHeader
            }
        });
        if (response.ok) {
            const json = await response.json();
            if (json.data.length === 1) {
                return parseInt(json.data[0].id);
            } else {
                throw new Error('Unable to find the specified application name and version');
            }
        } else {
            tl.error(`Response status: ${response.status}`);
            tl.error(await response.text());
            throw new Error('Failed to get application version ID');
        }
    }
}

async function uploadArtifact(): Promise<number> {
    const endpoint = trimUrl(settings.sscUrl) + `/api/v1/projectVersions/${projectVersionId}/artifacts`;
    const fileStream = fs.createReadStream(settings.scanFilePath);
    const form = new FormData();
    form.append('file', fileStream);
    const fortifyToken = uuid.validate(sscCiToken) ? Buffer.from(sscCiToken).toString('base64') : sscCiToken;
    const authHeader = 'FortifyToken ' + fortifyToken;
    console.log(`Uploading ${settings.scanFilePath} to ${settings.sscUrl}`);
    const response = await fetch(endpoint, {
        method: 'POST',
        agent: proxyAgent,
        body: form,
        headers: {
            'Authorization' : authHeader
        }
    });
    if (response.ok) {
        console.log('Background submission succeeded');
        const json = await response.json();
        return parseInt(json.data.id);
    } else {
        tl.error(`Response status: ${response.status}`);
        tl.error(await response.text());
        throw new Error('Failed to upload FPR to SSC');
    }
}

async function pollArtifactState(id: number) {
    if (!id) {
        throw new Error('Failed to get artifact Id');
    }

    let endpoint = trimUrl(settings.sscUrl) + `/api/v1/artifacts/${id}`;

    let timeoutInMinutes: number = parseInt(settings.timeoutForPollingArtifactState);
    if (!timeoutInMinutes) {
        timeoutInMinutes = 0;
    }
    const timeoutInMills: number = timeoutInMinutes * 60 * 1000;
    const timeout: number = timeoutInMills === 0 ? 0 : new Date().getTime() + timeoutInMills;
    let interval: number = parseInt(settings.intervalForPollingArtifactState);
    if (!interval) {
        interval = 1;
    }
    let processing: boolean = true;
    const fortifyToken = uuid.validate(sscCiToken) ? Buffer.from(sscCiToken).toString('base64') : sscCiToken;
    const authHeader = 'FortifyToken ' + fortifyToken;
    while (processing) {
        const response = await fetch(endpoint, {
            method: 'GET',
            agent: proxyAgent,
            headers: {
                'Authorization' : authHeader
            }
        });

        if (response.ok) {
            const json = await response.json();
            let state = json.data.status;
            processing = await checkState(state, processing, timeout, interval);
        } else {
            if (response.status === 404) {
                tl.error('Build failure criteria is supported in ScanCentral 22.1.0 and later');
            } else {
                tl.error(`Response status: ${response.status}`);
                tl.error(await response.text());
            }
            throw new Error('Failed to get Job Status');
        }
    }
}

function parseXml(xml: string): Promise<any> {
    return new Promise((resolve, reject) => {
        const parser = new xml2js.Parser( { trim: true, explicitArray: false});
        parser.parseString(xml, (error: any, result: any) => {
            if (error) {
                reject(error);
            } else {
                resolve(result);
            }
        });
    });
}

async function calcStats(buildFailureCriteria: string): Promise<void> {
    let defaultFilterSet: FilterSet = await getDefaultFilterSet();
    let issueFolder: IssueFolder[] = await getIssueGroupFolders(defaultFilterSet.guid, buildFailureCriteria);
    if (issueFolder.length) {
        let totalCount: number = 0;
        issueFolder.forEach((issue) => { totalCount += issue.totalCount });
        throw new BuildFailureError('Build failure criteria matches. Total count: ' + totalCount);
    }
}

async function deleteTempToken() {
    if (tokenId) {
        let endpoint = trimUrl(settings.sscUrl) + `/api/v1/tokens/${tokenId}`;

        const response = await fetch(endpoint, {
            method: 'DELETE',
            agent: proxyAgent,
            headers: {
                'Authorization' : 'Basic ' + Buffer.from(`${settings.fortifyAuthUser}:${settings.fortifyAuth}`).toString('base64')
            }
        });

        if (!response.ok) {
            console.warn(`Failed to delete auth token: ${response.status}`);
        }
        tokenId = null;
    }
}

function sleep(mins: number) {
    const ms: number = mins * 60 * 1000;
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function getDefaultFilterSet() : Promise<FilterSet> {
    let endpoint = trimUrl(settings.sscUrl) + `/api/v1/projectVersions/${projectVersionId}/filterSets`;
    const fortifyToken = uuid.validate(sscCiToken) ? Buffer.from(sscCiToken).toString('base64') : sscCiToken;
    const authHeader = 'FortifyToken ' + fortifyToken;
        const response = await fetch(endpoint, {
        method: 'GET',
        agent: proxyAgent,
        headers: {
            'Authorization' : authHeader
        }
    });

    if (response.ok) {
        const json = await response.json();
        for (const filterSet of json.data) {
            if (filterSet.defaultFilterSet) {
                return filterSet;
            }
        }
        throw new Error('Failed to get Default FilterSet');
    } else {
        tl.error(`Response status: ${response.status}`);
        tl.error(await response.text());
        throw new Error('Failed to get Default FilterSet');
    }
}

async function getIssueGroupFolders(filterSetGuid: string, searchCondition: string): Promise<IssueFolder[]> {
    let endpoint = trimUrl(settings.sscUrl) + `/api/v1/projectVersions/${projectVersionId}/issueGroups`;

    const params = { qm:'issues', q:`${searchCondition}`, filterset:`${filterSetGuid}`, groupingtype: 'FOLDER' };
    const query = new URLSearchParams(params);
    const fortifyToken = uuid.validate(sscCiToken) ? Buffer.from(sscCiToken).toString('base64') : sscCiToken;
    const authHeader = 'FortifyToken ' + fortifyToken;
    const response = await fetch(endpoint + '?' + query, {
        method: 'GET',
        agent: proxyAgent,
        headers: {
            'Authorization' : authHeader
        }
    });

    if (response.ok) {
        const json = await response.json();
        return json.data;
    } else {
        const msg = `Failed to retrieve issue groups for the application version ID: ${projectVersionId}`;
        tl.error(msg);
        tl.error(`Response status: ${response.status}`);
        tl.error(await response.text());
        throw new Error(msg);
    }
}

function trimUrl(url: string) {
    url = url.trim();
    if (url.endsWith('/')) {
        url = url.substring(0, url.length - 1);
    }
    return url;
}

class FilterSet {
    guid: string;
    title: string;
    description: string;
    folders: Folder[];
}

class Folder {
    id: number;
    guid: string;
    name: string;
    color: string;
}

class IssueFolder {
    id: string;
    cleanName: string;
    name: string;
    totalCount: number;
    auditCount: number;
    visibleCount: number;
}

class TimeoutError extends Error {
    constructor(message?: string) {
        super(message);
    }
}

class BuildFailureError extends Error {
    constructor(message?: string) {
        super(message);
    }
}

run();
